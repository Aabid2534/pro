﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ProductM.Models
{
    public class Login
    {
        [Key]

        [Required(ErrorMessage ="Please enter a valid email")]

        [Display(Name ="Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter a valid password")]

        [Display(Name = "Password")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
