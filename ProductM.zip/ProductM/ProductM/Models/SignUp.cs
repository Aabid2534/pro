﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace ProductM.Models
{
    public class SignUp
    {
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="Please enter your fname")]
        [Display(Name = "Firstname")]
        public string FirstName { get; set; }
        [Required(ErrorMessage = "Please enter your lname")]
        [Display(Name = "LastName")]
        public string LastName { get; set; }
        [Required(ErrorMessage = "Please enter your Email")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your password")]
        [Display(Name = "password")]
        [DataType(DataType.Password)]
        public string password { get; set; }

        [Required(ErrorMessage = "Please enter your conpassword")]
        [Display(Name = "confirmpassword")]
        [DataType(DataType.Password)]
        [Compare("password")]
        public string confirmpassword { get; set; }

        public bool IsActive { get; set; }


    }
}
