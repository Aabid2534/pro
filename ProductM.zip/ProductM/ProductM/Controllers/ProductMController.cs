﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ProductM.Models;
using Microsoft.EntityFrameworkCore;
namespace ProductM.Controllers
{
    public class ProductMController : Controller
    {
        private ApplicationDbContext dbContext;

        public ProductMController(ApplicationDbContext _dbContext)
        {
            dbContext = _dbContext;
        }
        public IActionResult Index()
        {
            var emps = dbContext.signUps.ToList();
            return View(emps);
        }

        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(SignUp sign)
        {
            dbContext.signUps.Add(sign);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
